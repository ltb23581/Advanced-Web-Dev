package edu.uga.cs.tripcost;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private static final String DEBUG_TAG = "TripCost";

    private EditText distanceEditText;
    private EditText gasEditText;
    private EditText mpgEditText;
    private TextView tripCostTextView;
    private Button compute;

    private String tripCostString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Log.i( DEBUG_TAG, "MainActivity.onCreate()" );

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Obtain references to the UI objects in the layout
        compute = findViewById(R.id.button);
        distanceEditText = findViewById(R.id.editTextNumberDecimal);
        gasEditText = findViewById(R.id.editTextNumberDecimal2);
        mpgEditText = findViewById(R.id.editTextNumberDecimal3);
        tripCostTextView = findViewById(R.id.textView);

        // Set the compute Button's listener
        compute.setOnClickListener(new ButtonClickListener());
    }

    // The listener here is defined as a private inner class which provides the onClick method implementation
    private class ButtonClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            double distance;
            double mpg;
            double gasPerGal;
            double tripCost = 0.0;

            try {
                // Obtain the values entered by the user and parse them to double
                distance = Double.parseDouble(distanceEditText.getText().toString());
                mpg = Double.parseDouble(mpgEditText.getText().toString());
                gasPerGal = Double.parseDouble(gasEditText.getText().toString());
            } catch (NumberFormatException nfe) {
                // Display a Toast message if the input is not a valid number
                Toast toast = Toast.makeText(getApplicationContext(),
                        "Enter positive decimal values",
                        Toast.LENGTH_SHORT);
                toast.show();
                tripCostTextView.setText("$0.00");
                return;
            }

            // Check if all values are positive
            if (distance <= 0 || mpg <= 0 || gasPerGal <= 0) {
                Toast toast = Toast.makeText(getApplicationContext(),
                        "All values must be positive",
                        Toast.LENGTH_SHORT);
                toast.show();
                tripCostTextView.setText("$0.00");
                return;
            }

            // Compute the trip cost
            tripCost = distance / mpg * gasPerGal;

            // Prepare the computed trip cost as a String, with value rounded to a cent
            DecimalFormat df = new DecimalFormat("####0.00");
            tripCostString = "$" + df.format(tripCost);

            // Update the trip cost TextView text with the computed cost
            tripCostTextView.setText(tripCostString);
        }
    }

    // These activity callback methods are not needed and are for educational purposes only
    @Override
    protected void onStart() {
        Log.d( DEBUG_TAG, "MainActivity.onStart()" );
        super.onStart();
    }

    @Override
    protected void onResume() {
        Log.d( DEBUG_TAG, "MainActivity.onResume()" );
        super.onResume();
    }

    @Override
    protected void onPause() {
        Log.d( DEBUG_TAG, "MainActivity.onPause()" );
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d( DEBUG_TAG, "MainActivity.onStop()" );
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d( DEBUG_TAG, "MainActivity.onDestroy()" );
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        Log.d( DEBUG_TAG, "MainActivity.onRestart()" );
        super.onRestart();
    }
}
